// Write your JavaScript code here
window.addEventListener("load", () => {
  const content = document.querySelector(".content");
  content.classList.add("fade-in");
});
